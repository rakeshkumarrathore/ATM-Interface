package ATMMachine;

public class Main {
    public static void main(String[] args) {
        BankAccount myAccount = new BankAccount(1000.00); // Starting with a balance of $1000
        ATM atm = new ATM(myAccount);
        atm.displayMenu();
    }
}

